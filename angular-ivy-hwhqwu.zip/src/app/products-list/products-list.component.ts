import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { from } from 'rxjs';
import {Product} from '../product.model';

@Component({
  selector: 'products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent {
  private currentProduct: Product;

  constructor() {
this.onProductSelected = new EventEmitter();
 }

  
  clicked(product: Product): void {
 this.currentProduct = product;
 this.onProductSelected.emit(product);
 }
 isSelected(product: Product): boolean {
 if (!product || !this.currentProduct) {
 return false;
 }
 return product.sku === this.currentProduct.sku;
 }


}