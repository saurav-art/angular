import { Component, Input, } from '@angular/core';

@Component({
  selector: 'product-displaly',
  templateUrl: `
 <div class="price-display">\${{ price }}</div>
`,
  styleUrls: ['./product-displaly.component.css']
})
export class ProductDisplalyComponent {

  @Input() price: number;

}