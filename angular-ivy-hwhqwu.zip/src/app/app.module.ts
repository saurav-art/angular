import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { ProductRowComponent } from './product-row/product-row.component';
import { ProductImageComponent } from './product-image/product-image.component';
import { ProductDisplalyComponent } from './product-displaly/product-displaly.component';
import { ProductDepartmentComponent } from './product-department/product-department.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent, ProductListComponent, ProductsListComponent, ProductRowComponent, ProductImageComponent, ProductDisplalyComponent, ProductDepartmentComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
