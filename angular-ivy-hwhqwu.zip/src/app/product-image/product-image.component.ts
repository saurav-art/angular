import { Component, Input,HostBinding } from '@angular/core';

@Component({
  selector: 'product-image',
  templateUrl: `<img class="product-image" [src]="product.imageUrl">`,
  styleUrls: ['./product-image.component.css']
})
export class ProductImageComponent {

 @Input() product: Product;
 @HostBinding('attr.class') cssClass = 'ui small image';
  

}